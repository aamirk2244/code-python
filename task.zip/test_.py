from task import ret_lst
from task import store_dict
from task import search
from task import out_file

def test_task1_test1():
    lst = ret_lst("inp.csv")
    assert lst[0] == ['ID', 'C1', 'C2', 'C3', 'C4', 'C5']

def test_task1_test2():
    lst = ret_lst("inp.csv")
    assert lst[-2] == ['P21-0019', '34', '23', '50', '61', '53']

def test_task1_test3():
    lst = ret_lst("inp.csv")
    assert lst[5] == ['P21-0005', '73', '77', '59', '8', '6']


def test_task1_test4():
    lst = ret_lst("inp2.csv")
    assert lst[15] == ['P21-0015', '25', '24', '59', '29', '81']


def test_task1_test5():
    lst = ret_lst("inp2.csv")
    assert lst[12] == ['P21-0012', '18', '84', '5', '35', '14']


def test_task2_test1():
	dic = store_dict("inp.csv")
	assert dic['P21-0001'] == [(87, 91, 72, 45, 41)]
	

def test_task2_test2():
	dic = store_dict("inp.csv")
	assert dic['P21-0011'] == [(50, 20, 6, 70, 21)]

def test_task2_test3():
	dic = store_dict("inp.csv")
	assert dic['P21-0009'] == [(42, 45, 29, 100, 69)]

def test_task2_test4():
	dic = store_dict("inp2.csv")
	assert dic['P21-0001'] == [(11, 11, 75, 53, 54)]

def test_task2_test5():
	dic = store_dict("inp2.csv")
	assert dic['P21-0018'] == [(79, 100, 23, 19, 54)]


def test_task3_test1():
	assert search("inp.csv",'P21-0009') == [(42, 45, 29, 100, 69), (57.0, 'B')]

def test_task3_test2():
	assert search("inp.csv",'P21-0016') == [(79, 13, 67, 59, 51), (53.8, 'B')]

def test_task3_test3():
	assert search("inp2.csv",'P21-0017') == [(43, 43, 16, 61, 98), (52.2, 'B')]

def test_task3_test4():
	assert search("inp2.csv",'P21-0013') == [(27, 81, 8, 29, 86), (46.2, 'F')]

def test_task3_test5():
	assert search("inp2.csv",'P21-009') == None

def test_task4_test1():
	out_file("inp.csv" , "out.csv")
	with open("out.csv","r") as f:
		assert f.read().strip() == """ID,C1,C2,C3,C4,C5,Per,Grade
P21-0001,87,91,72,45,41,67.2,B
P21-0002,23,71,40,85,17,47.2,F
P21-0003,79,58,19,4,85,49.0,F
P21-0004,50,69,40,36,13,41.6,F
P21-0005,73,77,59,8,6,44.6,F
P21-0006,8,99,32,12,74,45.0,F
P21-0007,84,25,18,66,56,49.8,F
P21-0008,98,80,46,14,8,49.2,F
P21-0009,42,45,29,100,69,57.0,B
P21-0010,54,42,8,90,37,46.2,F
P21-0011,50,20,6,70,21,33.4,F
P21-0012,10,51,31,42,60,38.8,F
P21-0013,26,14,38,51,59,37.6,F
P21-0014,1,33,20,22,99,35.0,F
P21-0015,24,25,44,22,83,39.6,F
P21-0016,79,13,67,59,51,53.8,B
P21-0017,4,61,76,7,90,47.6,F
P21-0018,99,58,54,54,70,67.0,B
P21-0019,34,23,50,61,53,44.2,F
P21-0020,51,61,22,69,60,52.6,B"""


def test_task4_test2():
	out_file("inp2.csv" , "out2.csv")
	with open("out2.csv","r") as f:
		assert f.read().strip() == """ID,C1,C2,C3,C4,C5,Per,Grade
P21-0001,11,11,75,53,54,40.8,F
P21-0002,78,2,6,92,96,54.8,B
P21-0003,96,11,75,53,32,53.4,B
P21-0004,25,93,70,18,4,42.0,F
P21-0005,98,44,17,26,30,43.0,F
P21-0006,56,73,76,35,54,58.8,B
P21-0007,30,59,79,57,46,54.2,B
P21-0008,90,1,61,48,37,47.4,F
P21-0009,42,2,57,15,4,24.0,F
P21-0010,14,8,4,95,94,43.0,F
P21-0011,24,32,31,61,48,39.2,F
P21-0012,18,84,5,35,14,31.2,F
P21-0013,27,81,8,29,86,46.2,F
P21-0014,83,92,31,10,75,58.2,B
P21-0015,25,24,59,29,81,43.6,F
P21-0016,85,14,56,13,77,49.0,F
P21-0017,43,43,16,61,98,52.2,B
P21-0018,79,100,23,19,54,55.0,B
P21-0019,86,2,77,77,96,67.6,B
P21-0020,73,81,84,29,4,54.2,B"""


