import pandas as pd
import numpy as np
import pprint
############### Function ret_lst() ###############

def ret_lst(fileName):
    df = pd.read_csv(fileName)
    l = []
    column = list(df.columns)
    l.append(column)
    # print(l)
    # print(df[column[0]])
    for i in range(len(df)):
        l.append(list(df.iloc[i,:].values))
  
    # pprint.pprint(l)
    return l








############### Function store_dict() ###############

def store_dict(fileName):
    data =  ret_lst(fileName)
    dict = {}
    tupl = ()
    count = 0
    firstRow = True
    k = None
    # print(data)
    for i in data:
        count = 0
        tupl = []
        if firstRow:
            firstRow = False
            continue
        for j in i:
            if count == 0:
                k = j
                dict[k] = []
            elif count == len(i)-1:              # last element
                tupl.append(j)
                tupl = tuple(tupl)
                       # k is key
                dict[k].append(tupl)
            else:
                tupl.append(j)
                
            count += 1
               
    
    return dict




############### Function search() ###############

def search(fileName, key):
    data = store_dict(fileName)

    try: data[key]
    except:return None
    sumVar = 0
    percent = (sum(data[key][0])/500)*100
    
    if(percent > 85) : data[key].append( (percent,'A'))
    elif(percent > 50) : data[key].append( (percent,'B'))
    elif(percent <= 50) : data[key].append( (percent,'F'))
    return(data[key])

    # print(avrg)
    #     Percentage > 85 ; Grade = A
# Percentage > 50 ; Grade = B
# Percentage <= 50 ; Grade = F

############### Function out_file() ###############

def out_file(fileName, outFile):
    df = pd.read_csv(fileName)
    print(df)
    percentages = []
    grades = []
    data = store_dict(fileName)
    keys = list(data.keys())
    for k in keys:
        percent = (sum(data[k][0])/500)*100
        if(percent > 85) : data[k].append( (percent,'A'))
        elif(percent > 50) : data[k].append( (percent,'B'))
        elif(percent <= 50) : data[k].append( (percent,'F'))
        percentages.append(data[k][1][0])
        grades.append( data[k][1][1])
    
    df['Perc'] = list(percentages)
    df['Grade'] = list(grades)
    df.to_csv(outFile)
    # print(percentages)
fileName = 'inp.csv'
# ret_lst(fileName)
# store_dict(fileName)
# search(fileName, 'P21-0020')
out_file(fileName, 'outputFile.csv')